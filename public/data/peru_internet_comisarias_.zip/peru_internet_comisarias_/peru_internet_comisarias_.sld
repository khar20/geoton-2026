<StyledLayerDescriptor version="1.0.0" xmlns="http://www.opengis.net/sld" xmlns:gml="http://www.opengis.net/gml" xmlns:ogc="http://www.opengis.net/ogc" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xsi:schemaLocation="http://www.opengis.net/sld http://schemas.opengis.net/sld/1.0.0/StyledLayerDescriptor.xsd">
  <NamedLayer>
    <Name>peru_internet_comisarias</Name>
    <UserStyle>
      <FeatureTypeStyle>
        <Rule>
          <Name>Tiene internet</Name>
          <ogc:Filter>
            <ogc:PropertyIsEqualTo>
              <ogc:PropertyName>inf_329_17</ogc:PropertyName>
              <ogc:Literal>1</ogc:Literal>
            </ogc:PropertyIsEqualTo>
          </ogc:Filter>
           <PointSymbolizer>
             <Graphic>
               <Mark>
                 <WellKnownName>square</WellKnownName>
                 <Fill>
                   <CssParameter name="fill">#00c800</CssParameter>
                 </Fill>
                  <Stroke>
                    <CssParameter name="stroke">#006900</CssParameter>
                    <CssParameter name="stroke-width">1.00</CssParameter>
           		 </Stroke>
               </Mark>
               <Size>8</Size>
             </Graphic>
 			</PointSymbolizer>
                  

        </Rule>
        <Rule>
          <Name>No tiene internet</Name>
          <ogc:Filter>
            <ogc:PropertyIsEqualTo>
              <ogc:PropertyName>inf_329_17</ogc:PropertyName>
              <ogc:Literal>2</ogc:Literal>
            </ogc:PropertyIsEqualTo>
          </ogc:Filter>
            <PointSymbolizer>
             <Graphic>
               <Mark>
                 <WellKnownName>circle</WellKnownName>
                 <Fill>
                   <CssParameter name="fill">#ff2200</CssParameter>
                 </Fill>
                  <Stroke>
                    <CssParameter name="stroke">#a80000</CssParameter>
                    <CssParameter name="stroke-width">1.00</CssParameter>
           		 </Stroke>
               </Mark>
               <Size>8</Size>
             </Graphic>
 			</PointSymbolizer>
        </Rule>
        
        <Rule>
          <Name>Sin información</Name>
          <ogc:Filter>
            <ogc:PropertyIsEqualTo>
              <ogc:PropertyName>inf_329_17</ogc:PropertyName>
              <ogc:Literal>0</ogc:Literal>
            </ogc:PropertyIsEqualTo>
          </ogc:Filter>
          <PointSymbolizer>
        
             <Graphic>
               <Mark>
                 <WellKnownName>triangle</WellKnownName>
                 <Fill>
                   <CssParameter name="fill">#e1e1e1</CssParameter>
                 </Fill>
                  <Stroke>
                    <CssParameter name="stroke">#343434</CssParameter>
                    <CssParameter name="stroke-width">1.00</CssParameter>
           		 </Stroke>
               </Mark>
               <Size>10</Size>
             </Graphic>
 			</PointSymbolizer>
        </Rule>
        
        
        <Rule>
          <MaxScaleDenominator>1000000</MaxScaleDenominator>
          <TextSymbolizer>
            <Label>
              <ogc:PropertyName>nombre_com</ogc:PropertyName>
            </Label>
            <Font>
              <CssParameter name="font-family">MS Shell Dlg 2</CssParameter>
              <CssParameter name="font-size">9</CssParameter>
            </Font>
            <LabelPlacement>
              <PointPlacement>
                <AnchorPoint>
                  <AnchorPointX>0.5</AnchorPointX>
                  <AnchorPointY>2.5</AnchorPointY>
                </AnchorPoint>
              </PointPlacement>
            </LabelPlacement>
            <Fill>
              <CssParameter name="fill">#ffffff</CssParameter>
            </Fill>
          </TextSymbolizer>
        </Rule>
      </FeatureTypeStyle>
    </UserStyle>
  </NamedLayer>
</StyledLayerDescriptor>